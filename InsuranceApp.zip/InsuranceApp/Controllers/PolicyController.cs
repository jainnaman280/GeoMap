﻿using InsuranceApp.Data;
using InsuranceApp.Models;
using InsuranceApp.Models.ViewModel;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace InsuranceApp.Controllers
{
    public class PolicyController : Controller
    {
        private readonly Dictionary<string, Dictionary<string, int>> dict;
        private readonly ApplicationDbContext _db;
        public PolicyController(ApplicationDbContext db)
        {
            _db = db;
            dict = new Dictionary<string, Dictionary<string, int>>();
        }
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(CreatePolicy obj)
        {
            
            if (ModelState.IsValid)
            {
                string customerNum = DateTime.Now.Ticks.ToString().Substring(0, 5);

                obj.customer.CustomerNumber = customerNum;
                _db.Customer.Add(obj.customer);
                _db.SaveChanges();
                int id = obj.customer.Id;

                if(id > 0)
                {
                    string policyNum = "IN" + DateTime.Now.Ticks.ToString().Substring(5, 5);
                    obj.policy.policyNumber = policyNum;
                    obj.policy.Customer_Id = id;
                    _db.Policy.Add(obj.policy);
                    _db.SaveChanges();

                    return RedirectToAction("index", "home");
                }
                else
                {
                    return View(obj);
                }
            }
            return View(obj);
        }

        public IActionResult Update(int? id)
        {
            if (id == null || id == 0)
            {
                return NotFound();
            }
            var obj = _db.Policy.Find(id);
            if (obj == null)
            {
                return NotFound();
            }

            CreatePolicy _policy = new CreatePolicy();
            _policy.policy = obj;
            _policy.customer = _db.Customer.First(i => i.Id == obj.Customer_Id);

            return View(_policy);
        }

        [HttpPost]
        public IActionResult Update(CreatePolicy obj)
        {
            if (ModelState.IsValid)
            {
                _db.Customer.Update(obj.customer);
                _db.SaveChanges();

                int id = obj.customer.Id;
                if (id > 0)
                {
                    obj.policy.Customer_Id = id;
                    _db.Policy.Update(obj.policy);
                    _db.SaveChanges();

                    return RedirectToAction("index", "home");
                }
                else
                {
                    return View(obj);
                }
            }

            return View(obj);
        }

        public IActionResult ViewChart()
        {
            return View();
        }

        [HttpGet]
        [Route("api/getDetails")]
        public IActionResult ShowChart(string region)
        {
            IEnumerable<Policy> objList = _db.Policy;

            List<object> list = new List<object>();
            var grouped = from p in objList
                          group p by new { month = p.Date.ToString("MMM") } into d
                          select new { dt = string.Format("{0}", d.Key.month), count = d.Count() };

            
            foreach (var item in grouped)
            {
                list.Add(new { label = item.dt, value = item.count });
            }
            var arr = list.ToArray();
           
            return Json(arr);
            
        }
    }
}
