﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace InsuranceApp.Models
{
    public class Policy
    {
        [Key]
        public int Policy_Id { get; set; }
        [Required]
        public DateTime Date { get; set; }
        public int Customer_Id { get; set; }
        public string Fuel { get; set; }
        [Display(Name ="Vechicle Segment")]
        public string Vechicle_Segment { get; set; }
        [Required]
        [Range(1, 1000000, ErrorMessage = "Amount must be greater than 0 and less than 1,000,000")]
        public long Premium { get; set; }
        [Display(Name="Body Injury Liability")]
        public bool Body_Injury_Liability { get; set; }
        [Display(Name ="Personal Injury Protection")]
        public bool Personal_Injury_Protection { get; set; }
        [Display(Name ="Property Injury Liability")]
        public bool Property_Injury_Liability { get; set; }
        public bool Collision { get; set; }
        public bool Comprehensive { get; set; }

        [ForeignKey("Customer_Id")]
        public virtual Customer customer { get; set; }
        public string policyNumber { get; set; }
    }
}
