﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InsuranceApp.Models.ViewModel
{
    public class CreatePolicy
    {
        public Policy policy { get; set; }
        public Customer customer { get; set; }
    }
}
