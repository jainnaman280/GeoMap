﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace InsuranceApp.Models
{
    public class Customer
    {
        [Key]
        public int Id { get; set; }
        [Required]
        [Display(Name ="Customer Name")]
        public string Name { get; set; }
        public string Gender { get; set; }
        [Display(Name="Income Group")]
        public string Income_Group { get; set; }
        public string Region { get; set; }
        [Display(Name="Marital Status")]
        public bool Marital_Status { get; set; }
        public string CustomerNumber { get; set; }
    }
}
