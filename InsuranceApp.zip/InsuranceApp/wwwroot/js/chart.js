﻿GetPolicyDetails("");

async function GetPolicyDetails(Region) {
    try {
        let res = await fetch('/api/getDetails?region=' + Region);
        let response = await res.json();
        let data = response
        //console.log(response);

        let lineChart = new TChart("lineChart", 600, 450, data);
        let barChart = new TChart("barChart", 600, 450, data);
        lineChart.drawLineChart({ animation: true });
        barChart.drawBarChart({ animation: true });
    } catch (error) {
        console.log(error);
        alert("Some error occured!! Please try again")
    }
}