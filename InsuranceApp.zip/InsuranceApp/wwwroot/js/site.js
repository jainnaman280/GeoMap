﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.

$(document).ready(function () {
    $('#dtBasicExample').DataTable();
    $('.dataTables_length').addClass('bs-select');

    //$("input").on("change", function () {
    //    this.setAttribute(
    //        "data-date",
    //        moment(this.value, "YYYY-MM-DD")
    //            .format(this.getAttribute("data-date-format"))
    //    )
    //}).trigger("change")

    $('#datetimepicker2').datepicker({
        weekStart: 0,
        todayBtn: "linked",
        language: "en",
        orientation: "bottom auto",
        keyboardNavigation: false,
        autoclose: true,
        format: 'yyyy-mm-dd'
    });
});

function handler(e) {
    console.log(e.target.value);
    alert("You can't update policy date");
    $('#txt_date').val(e.target.defaultValue);
    return;
}
